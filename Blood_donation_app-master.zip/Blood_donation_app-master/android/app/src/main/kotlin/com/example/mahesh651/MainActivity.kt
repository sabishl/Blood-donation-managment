package com.example.mahesh651

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
